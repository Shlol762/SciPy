class UnitError(Exception):
    pass